package com.krishna;

public interface AnimalI {
    String makeSound();
    String whatAmI();
}
